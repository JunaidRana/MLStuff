# -*- coding: utf-8 -*-
"""
Created on Thu Oct 11 13:45:01 2018

@author: Junaid.raza
"""
import os
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

bot=ChatBot('Bot')
bot.set_trainer(ListTrainer) 

#Replace the file path as your PC
for files in os.listdir('E:/Work/GIT/Coding Practice Exercise/ChatBot/chatterbot-corpus-master/chatterbot_corpus/data/english/'):
    data=open('E:/Work/GIT/Coding Practice Exercise/ChatBot/chatterbot-corpus-master/chatterbot_corpus/data/english/' + files, 'r').readlines()
    bot.train(data)
    
while True:
    message=input('You:')
    if message.strip()!='bye':
            reply=bot.get_response(message)
            print ('ChatBot:', reply)
    if message.strip()=='bye':
            print ('ChatBot', 'bye')
            break
























































print ("Helo")